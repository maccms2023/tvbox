<?php
include('../confng.php');
$sql="SELECT * FROM virson ORDER BY id DESC limit 1";
$res=$mysql->query($sql);
$data=[];
if($res->num_rows >0){
while($row= mysqli_fetch_assoc($res)){
$data[]=array(
"id"=>$row["id"],
"virson"=>$row["virson"],
"turname"=>$row["turname"],
"quxanqa"=>$row["quxanqa"],
"url"=>$row["url"],
"create_time"=>$row["create_time"]
);

echo json_encode([
"id"=>$row["id"],
"virson"=>$row["virson"],
"turname"=>$row["turname"],
"quxanqa"=>$row["quxanqa"],
"url"=>$row["url"],
"create_time"=>to_time_ago($row["create_time"])
    ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES,);
}
}
//数据接json格式返回


function to_time_ago($time){
        $difference=time()-$time;
        if(!$difference)
        {
            return '1 سىكۇنىت بۇرۇن';
        }
        $time_rule = array (
            12 * 30 * 24 * 60 * 60 => ' يىلنىڭ ئالدىدا',
            30 * 24 * 60 * 60 => 'ئاينىڭ ئالدىدا',
            24 * 60 * 60 => 'كۈننىڭ ئالدىدا',
            60 * 60 => 'سائەت بۇرۇن',
            60 => 'مىنۇت بۇرۇن',
            1 => 'سىكۇنىت بۇرۇن'
        );
        foreach( $time_rule as $sec=>$my_str){
            $res=$difference/$sec;
            if($res>=1)
            {
                $t = round( $res );
                return $t . ' ' . $my_str;
            }
        }
    }
?>
