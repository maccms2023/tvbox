<?php
include('../confng.php');
$sql = "SELECT * FROM app ORDER BY IFNULL(id,0) DESC";
$res=$mysql->query($sql);
$data=[];
if($res->num_rows >0){
while($row= mysqli_fetch_assoc($res)){
$data[]=array(
"id"=>$row["id"],
"title"=>$row["title"],
"logo"=>$row["logo"],
"desc1"=>$row["turname"],
"desc"=>$row["quxanqa"],
"url"=>$row["url"],
"image1"=>$row["image1"],
"image2"=>$row["image2"],
"daxiao"=>$row["daxiao"],
"create_time"=>$row["create_time"]
);

echo json_encode([
"id"=>$row["id"],
"title"=>$row["title"],
"logo"=>$row["logo"],
"desc1"=>$row["turname"],
"desc"=>$row["quxanqa"],
"url"=>$row["url"],
"image1"=>$row["image1"],
"image2"=>$row["image2"],
"daxiao"=>$row["daxiao"],
"create_time"=>to_time_ago($row["create_time"])
    ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES,);
}
}
//数据接json格式返回


function to_time_ago($time){
        $difference=time()-$time;
        if(!$difference)
        {
            return '1 分以前 ';
        }
        $time_rule = array (
            12 * 30 * 24 * 60 * 60 => ' 年以前 ',
            30 * 24 * 60 * 60 => '月以前 ',
            24 * 60 * 60 => '日以前 ',
            60 * 60 => '时以前 ',
            60 => '分以前 ',
            1 => '分以前 '
        );
        foreach( $time_rule as $sec=>$my_str){
            $res=$difference/$sec;
            if($res>=1)
            {
                $t = round( $res );
                return $t . ' ' . $my_str;
            }
        }
    }
?>
