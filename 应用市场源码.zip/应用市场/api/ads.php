<?php
include('../confng.php');
$sql="SELECT * FROM ads";
$res=$mysql->query($sql);
$data=[];
if($res->num_rows >0){
while($row= mysqli_fetch_assoc($res)){
$data[]=array(
"id"=>$row["id"],
"wenads"=>$row["wenads"],
"imads1"=>$row["imads1"],
"imads2"=>$row["imads2"],
"imads3"=>$row["imads3"],
"imads4"=>$row["imads4"],
"imads5"=>$row["imads5"],
"viads"=>$row["viads"]
);

echo json_encode([
"id"=>$row["id"],
"wenads"=>$row["wenads"],
"imads1"=>$row["imads1"],
"imads2"=>$row["imads2"],
"imads3"=>$row["imads3"],
"imads4"=>$row["imads4"],
"imads5"=>$row["imads5"],
"viads"=>$row["viads"]
    ],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES,);
}
}
//数据接json格式返回


function to_time_ago($time){
        $difference=time()-$time;
        if(!$difference)
        {
            return '1 分以前 ';
        }
        $time_rule = array (
            12 * 30 * 24 * 60 * 60 => ' 年以前 ',
            30 * 24 * 60 * 60 => '月以前 ',
            24 * 60 * 60 => '日以前 ',
            60 * 60 => '时以前 ',
            60 => '分以前 ',
            1 => '分以前 '
        );
        foreach( $time_rule as $sec=>$my_str){
            $res=$difference/$sec;
            if($res>=1)
            {
                $t = round( $res );
                return $t . ' ' . $my_str;
            }
        }
    }
?>
