<?php
//BY:KOZYAX
if(isset($_FILES['file'])){
    
    
$fileEx=strtolower(substr(strrchr($_FILES["file"]["name"],"."),1));
$byte=$_FILES['file']['size'];
    $KB = 1024;
    $MB = 1024 * $KB;
    $GB = 1024 * $MB;
    $TB = 1024 * $GB;
    if ($byte < $KB) {
        $ali=$byte . "B";
    } elseif ($byte < $MB) {
         $ali=round($byte / $KB, 2) . "KB";
    } elseif ($byte < $GB) {
         $ali=round($byte / $MB, 2) . "MB";
    } elseif ($byte < $TB) {
        $ali=round($byte / $GB, 2) . "GB";
    } else {
         $ali=round($byte / $TB, 2) . "TB";
    }

if(is_uploaded_file($_FILES['file']['tmp_name']))
{
    $ext_suffix = pathinfo($_FILES["file"]["name"])['extension'];
 $allow_suffix = array('apk','zip');
 if(!in_array($ext_suffix, $allow_suffix)){
  $json = '{"code":400,"msg":"抱歉,您上传的数据,格式不支持！"}';
        echo $json;
 }else{
        $ret = array();
        $uploadDir = 'upload/kozyax_app'.DIRECTORY_SEPARATOR.date("Ymd").DIRECTORY_SEPARATOR;
        $dir = dirname(__FILE__).DIRECTORY_SEPARATOR.$uploadDir;
        file_exists($dir) || (mkdir($dir,0777,true) && chmod($dir,0777));
              if(!is_array($_FILES["file"]["name"])) //single file
              {
              $fileName = time().uniqid().'.'.pathinfo($_FILES["file"]["name"])['extension'];
              move_uploaded_file($_FILES["file"]["tmp_name"],$dir.$fileName);
              $ret['file'] =get_http_type().$_SERVER['SERVER_NAME'].DIRECTORY_SEPARATOR.$uploadDir.$fileName;
              }
        $json = '{"code":200,"msg":"'.$ret['file'].'","size":"'.$ali.'"}';
        echo $json;
 }
}else{
    $json = '{"code":400,"msg":"抱歉,您上传的数据,不是图片！"}';
    echo $json;
}
}
//自动获取协议头
function get_http_type()
{
    $http_type = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) ? 'https://' : 'http://';
    return $http_type;
}
?>