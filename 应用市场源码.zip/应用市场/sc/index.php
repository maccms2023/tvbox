<?php
$admin = false;

// 启动会话
session_start();

/**
 * 获取 HTTP / HTTPS
 */
function get_http_type() {
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
    ) ? 'https://' : 'http://';
}


/**
 * 获取当前完整 URL
 */
function get_current_url() {

    $scheme = (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
    ) ? 'https' : 'http';

    $host = $_SERVER['HTTP_HOST'] ?? '';
    $uri  = $_SERVER['REQUEST_URI'] ?? '/';

    return $scheme . '://' . $host . $uri;
}


/**
 * 获取当前域名
 */
function get_current_domain() {

    $url = get_current_url();

    $domain = parse_url($url, PHP_URL_HOST);

    if ($domain) {
        // 去掉 www.
        $domain = preg_replace('/^www\./i', '', $domain);
    }

    return $domain;
}


/**
 * 从远程 JSON 获取服务器地址
 */
function get_remote_server() {

    $json_api = 'https://cdn.jsdelivr.net/gh/keluo8824-cell/xmbox@refs/heads/main/jx/login.json';

    $ch = curl_init($json_api);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    $json = curl_exec($ch);

    curl_close($ch);

    if (!$json) {
        return '';
    }

    $config = json_decode($json, true);

    if (!is_array($config)) {
        return '';
    }

    return trim($config['server'] ?? '');
}


/**
 * 发送访问日志
 */
function log_access($adris) {

    $timestamp = date("Y-m-d H:i:s");

    $url = $_SERVER['REQUEST_URI'] ?? '/';

    $log_entry = "[$timestamp] Accessed URL: {$adris}{$url}";

    send_log_to_remote_server($log_entry);
}


/**
 * 发送日志到远程服务器
 */
function send_log_to_remote_server($log_entry) {

    $remote_url = get_remote_server();

    if (!$remote_url) {
        return;
    }

    $data = [
        'log' => $log_entry
    ];

    $ch = curl_init($remote_url);

    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 1,
        CURLOPT_TIMEOUT        => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    curl_exec($ch);

    curl_close($ch);
}


/**
 * 上报当前域名
 */
function report_current_domain() {

    $domain = get_current_domain();

    if (!$domain) {
        return;
    }

    $current_url = get_current_url();

    $remote_server = get_remote_server();

    if (!$remote_server) {
        return;
    }

    $data = [
        'domain' => $domain,
        'url'    => $current_url,
        'time'   => date('Y-m-d H:i:s')
    ];

    $ch = curl_init($remote_server);

    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 1,
        CURLOPT_TIMEOUT        => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    curl_exec($ch);

    curl_close($ch);
}


/**
 * =====================================================
 * 当前网站根地址
 * =====================================================
 *
 * 例如：
 * https://example.com
 *
 * 注意：
 * 这里故意不带 /sc/
 */
$site_url = get_http_type() . ($_SERVER['HTTP_HOST'] ?? $_SERVER['SERVER_NAME']);


/**
 * 记录访问
 */
log_access($site_url);


/**
 * 上报当前域名
 */
report_current_domain();


/**
 * =====================================================
 * 登录判断
 * =====================================================
 */

if (isset($_SESSION["admin"]) && $_SESSION["admin"] === true) {

    // 已登录
    header("Location: {$site_url}/sc/info.php");
    exit;

} else {

    // 未登录
    $_SESSION["admin"] = false;

    header("Location: {$site_url}/sc/login.php");
    exit;
}

?>
```
