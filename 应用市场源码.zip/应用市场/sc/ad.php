<?php
include('../confng.php');
$uid=1;
$title="桌面后台管理";

$sql="SELECT * FROM ads where id='{$uid}' ORDER BY id DESC";
$res12=$mysql->query($sql);
$row12=$res12->fetch_array(MYSQLI_ASSOC);


if($_GET['do']=='edat'){
$viads=$_POST['viads'];
$imads1=$_POST['imads1'];
$imads2=$_POST['imads2'];
$imads3=$_POST['imads3'];
$imads4=$_POST['imads4'];
$imads5=$_POST['imads5'];
$wenads=$_POST['wenads'];

//  $sql="INSERT INTO app(title,logo,desc,image1,image2,url,create_time)VALUES('{$title}','{$logo}','{$desc}','{$image1}','{$image2}','{$url}','{$create_time}')";
 $sql="UPDATE ads set viads='{$viads}',imads1='{$imads1}',imads2='{$imads2}',imads3='{$imads3}',imads4='{$imads4}',imads5='{$imads5}',wenads='{$wenads}' where id={$uid}";
if($mysql->query($sql)===TRUE){
    echo "<script>alert('修改成功');location.href='index.php';</script>";
}else{
    // echo "<script>alert('添加失败');location.href='../index.php';</script>";
     echo "<script>alert('修改失败');</script>";
}
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>网站配置</title>
    <link rel="stylesheet" href="vendor/layui/css/layui.css">
    <link rel="stylesheet" href="custom/css/style.css">
    <link rel="stylesheet" href="custom/css/font.css">
</head>
<body style="padding:0 10px;">
<div class="layui-col-xs10">
    <form class="layui-form" action="ad.php?do=edat" enctype="multipart/form-data" method="post">
        <div class="layui-form-item">
            <label class="layui-form-label">启动广告 :</label>
            <div class="layui-input-block">
              <input type="text" id="logo1" name="imads1" value="<?php echo $row12['imads1']?>" class="layui-input" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test1">
                <i class="layui-icon">&#xe67c;</i>图片上传
                </button>
            </div>
          </div>


          <div class="layui-form-item">
            <label class="layui-form-label">首页壁纸 :</label>
            <div class="layui-input-block">
              <input type="text" id="logo2" name="imads2" value="<?php echo $row12['imads2']?>" class="layui-input" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test2">
                <i class="layui-icon">&#xe67c;</i>图片上传
                </button>
            </div>
          </div>
          
          
          
            <div class="layui-form-item">
          <label class="layui-form-label">启动广告字 ：</label>
          <div class="layui-input-block">
            <input type="text" name="imads3" value="<?php echo $row12['imads3']?>" required  lay-verify="required" placeholder="请输入文本广告内容 ！" autocomplete="off" class="layui-input">
          </div>
        </div>
          
          
          
          <!--  <div class="layui-form-item">-->
          <!--  <label class="layui-form-label">图片4 :</label>-->
          <!--  <div class="layui-input-block">-->
          <!--    <input type="text" id="logo4" name="imads4" value="<?php echo $row12['imads4']?>" class="layui-input" style="margin-right: 95px;width: 95%;">-->
          <!--    <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test4">-->
          <!--      <i class="layui-icon">&#xe67c;</i>图片上传-->
          <!--      </button>-->
          <!--  </div>-->
          <!--</div>-->
          
          
          
          <!--  <div class="layui-form-item">-->
          <!--  <label class="layui-form-label">图片5 :</label>-->
          <!--  <div class="layui-input-block">-->
          <!--    <input type="text" id="logo5" name="imads5" value="<?php echo $row12['imads5']?>" class="layui-input" style="margin-right: 95px;width: 95%;">-->
          <!--    <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test5">-->
          <!--      <i class="layui-icon">&#xe67c;</i>图片上传-->
          <!--      </button>-->
          <!--  </div>-->
          <!--</div>-->
          

          
          
        <div class="layui-form-item">
          <label class="layui-form-label">广告字 ：</label>
          <div class="layui-input-block">
            <input type="text" name="wenads" value="<?php echo $row12['wenads']?>" required  lay-verify="required" placeholder="请输入文本广告内容 ！" autocomplete="off" class="layui-input">
          </div>
        </div>


        <div class="layui-form-item">
          <label class="layui-form-label">首页名称 ：</label>
          <div class="layui-input-block">
            <input type="text" name="viads" value="<?php echo $row12['viads']?>" required  lay-verify="required" placeholder="请输入视频广告地址" autocomplete="off" class="layui-input">
          </div>
        </div>


          <div class="layui-form-item">
            <div class="layui-input-block">
              <button class="layui-btn" lay-submit lay-filter="formDemo">确定</button>
              <button type="reset" class="layui-btn layui-btn-primary">恢复原状</button>
            </div>
          </div>
    </form>
</div>
<script src="vendor/js/jquery.js"></script>
<script src="vendor/layui/layui.js"></script>
<script src="custom/js/admin.js"></script>
<script>
    //Demo
    layui.use(['form','upload','element'], function(){
      var form = layui.form;
      var layer=layui.layer;
      var upload = layui.upload;
      var uploadInst = upload.render({
      elem: '#test1' //绑定元素
      ,url: '../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo1").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
 var uploadInst = upload.render({
      elem: '#test2' //绑定元素
      ,url: '../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo2").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
      
   var uploadInst = upload.render({
      elem: '#test3' //绑定元素
      ,url: '../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo3").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
      
      
      
  var uploadInst = upload.render({
      elem: '#test4' //绑定元素
      ,url: '../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo4").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
      
      
   var uploadInst = upload.render({
      elem: '#test5' //绑定元素
      ,url: '../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo5").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
      
      //上传软件
              upload.render({
                    elem:'#url1',
                    url:'https://app.kozyax.biz/upload.php',
                    accept:'file',         
 
                    before: function (obj) { //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                            index = layer.load(1); //上传loading //上传logo
                    },
                    done:function (res) {
                //   console.log(res)     
                   if(res.code==200){
                   layer.close(index)
                    $("#url").val(res.url);
                    $("#da_xao").val(res.size);
                    $("#wj_type").val(res.type);
                    layer.msg('上传成功', {icon: 1});   
                     }else{
                     layer.msg(res.msg, {icon: 5});     
                     }
                    },
                    error:function () {
                        console.log('上传失败', {icon: 5})
                    }
                })
      
    });
    </script>
</body>
</html>