<?php
session_start();
if(!isset($_SESSION['id'])) {
    $http="https://";
    $adris=$http.$_SERVER['HTTP_HOST'];
//   header("location:$adris/admin/index.php");
   echo "<script>alert('现在登录');location.href='$adris/admin/login.php';</script>";
}
?>