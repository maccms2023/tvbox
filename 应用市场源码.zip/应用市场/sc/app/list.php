<?php

include('../../confng.php');

if($_GET['do']=='del'){
  $id=$_GET['id'];

  $sql="DELETE FROM app where id='{$id}'";
  if($mysql->query($sql)===TRUE){
    echo "<script>alert('删除成功');location.href='list.php';</script>";
  }else {
       echo "<script>alert('删除失败');location.href='list.php';</script>";
  }
}


$sql="SELECt* FROM app ORDER BY id DESC";
$res=$mysql->query($sql);
$rows=array();
while($row=$res->fetch_array(MYSQLI_ASSOC)){
    $rows[]=$row;
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>双语企业网站后台</title>
    <link rel="stylesheet" href="../vendor/layui/css/layui.css">
    <link rel="stylesheet" href="../custom/css/style.css">
    <link rel="stylesheet" href="../custom/css/font.css">
</head>
<body class="layui-layout-body">
<div class="layui-col-xs12" style="overflow: scroll;height: 96%;">
    <table class="layui-table" >
        <colgroup>
          <col width="150">
          <col width="200">
          <col>
        </colgroup>
        <thead>
          <tr>
            <th>ID</th>
            <th>图标</th>
            <th>名称</th>
            <th>类别</th>
            <th>标准</th>
            <th>发送时间</th>
            <th>操作类</th>
          </tr> 
        </thead>
        <tbody >
            <?php foreach($rows as $row):?>
          <tr>
            <td><?php echo $row['id']?></td>
            <td><img style="width: 50px;height: 50px;border-radius: 20px;" src="<?php echo $row['logo']?>" alt=""></td>
            <td><?php echo $row['title']?></td>
             <td><?php echo $row['turname']?></td>
            <td><?php echo $row['daxiao']?></td>
            <td style="direction:ltr"><?php echo date('Y/m/d H:i:s',$row['create_time'])?></td>
            <td>
                <a href="idet.php?do=edit&id=<?php echo $row['id']?>">
                  <button type="button" class="btn btn-outline-success"><i class="layui-icon" style="font-size: 28px;color: blueviolet;">&#xe642;</i></button>
                </a>
                <a href="list.php?do=del&id=<?php echo $row['id']?>">
                <button onclick="if(confirm('你真不删除  ؟')==false)return false;" class="btn btn-outline-warning">
                  <i class="layui-icon" style="font-size: 28px;color: red;">&#xe640;</i>
                </button>
              </a>
             
              </td>
          </tr>
          <?php endforeach;?>
        </tbody>
      </table>
   
</div>
<script src="../vendor/js/jquery.js"></script>
<script src="../vendor/layui/layui.js"></script>
<script src="../custom/js/admin.js"></script>
<script>
    //JavaScript代码区域
    layui.use('element', function(){
        var element = layui.element;

    });
</script>
</body>
</html>
