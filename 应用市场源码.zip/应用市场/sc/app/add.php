<?php
include('../../confng.php');

if($_GET['do']=='add'){
  
$title=$_POST['title'];
$logo=$_POST['logo'];
$desc=$_POST['desc'];
$desc1=$_POST['desc1'];
$image1=$_POST['image1'];
$image2=$_POST['image2'];
$url=$_POST['url'];
$daxiao=$_POST['daxiao'];
$time=time();

//  $sql="INSERT INTO app(title,logo,desc,image1,image2,url,create_time)VALUES('{$title}','{$logo}','{$desc}','{$image1}','{$image2}','{$url}','{$create_time}')";
 $sql="INSERT INTO app(title,logo,quxanqa,image1,image2,url,daxiao,create_time)VALUES('{$title}','{$logo}','{$desc}','{$image1}','{$image2}','{$url}','{$daxiao}','{$time}')";
if($mysql->query($sql)===TRUE){
    echo "<script>alert('添加成功');location.href='../index.php';</script>";
}else{
    echo "<script>alert('添加失败');location.href='../index.php';</script>";
    //  echo("添加失败".$mysql->connect_eror);
}
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>网站配置</title>
    <link rel="stylesheet" href="../vendor/layui/css/layui.css">
    <link rel="stylesheet" href="../custom/css/style.css">
    <link rel="stylesheet" href="../custom/css/font.css">
</head>
<body style="padding:0 10px;">
<div class="layui-col-xs10">
    <form class="layui-form" action="add.php?do=add" enctype="multipart/form-data" method="post">
        <div class="layui-form-item">
            <label class="layui-form-label">应用:图标</label>
            <div class="layui-input-block">
              <input type="text" id="logo" name="logo" class="layui-input" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test1">
                <i class="layui-icon">&#xe67c;</i>图片上传
              </button>
            </div>
          </div>

        <div class="layui-form-item">
          <label class="layui-form-label">应用:名称</label>
          <div class="layui-input-block">
            <input type="text" name="title"  placeholder="请输入软件名称" autocomplete="off" class="layui-input">
          </div>
        </div>
        
        
         <div class="layui-form-item">
           <label class="layui-form-label">类别名称</label>
           <div class="layui-input-block">
              <input type="text" name="desc1"  placeholder="请输入类别名称" autocomplete="off" class="layui-input">
           </div>
         </div>
          <div class="layui-form-item">
         <label class="layui-input-block"style="font-size: 20px;color: red;">类别名称:你自己随便写项目名称，必须和当前页面上的相同。 </label>
        </div>
        
         <div class="layui-form-item">
           <label class="layui-form-label">应用截图</label>
           <div class="layui-input-block">
              <input type="text" name="desc"  placeholder="请输入软件描述" autocomplete="off" class="layui-input">
           </div>
         </div>
         
           
    

              <div class="layui-form-item">
            <label class="layui-form-label">第一图片</label>
            <div class="layui-input-block">
              <input type="text" id="image1" name="image1" class="layui-input" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test2">
                <i class="layui-icon">&#xe67c;</i>图片上传
              </button>
            </div>
          </div>
          
          
               <div class="layui-form-item">
            <label class="layui-form-label">第二图片</label>
            <div class="layui-input-block">
              <input type="text" id="image2" name="image2" class="layui-input" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="test3">
                <i class="layui-icon">&#xe67c;</i>图片上传
              </button>
            </div>
          </div>
          
          
          
        
        <!--<div class="layui-form-item">-->
        <!--  <label class="layui-form-label">电视剧</label>-->
        <!--  <div class="layui-input-block">-->
        <!--    <input type="radio" name="isqisim" value="1" title="电视剧">-->
        <!--    <input type="radio" name="isqisim" value="2" title="否" checked>-->
        <!--  </div>-->
        <!--</div>-->
        <div class="layui-form-item">
            <label class="layui-form-label">应用下载地址 ：</label>
            <div class="layui-input-block">
              <input type="text" id="url" name="url" class="layui-input" placeholder="请输入下载地址 ，扩展名 .apk" style="margin-right: 95px;width: 95%;">
              <button type="button" style="float: right;margin-top: -39px;border-radius: 0;border: 0;" class="layui-btn" id="url1">
                <i class="layui-icon">&#xe67c;</i>软件上传
              </button>
            </div>
          </div>
          
        <div class="layui-form-item">
          <label class="layui-form-label">app量 ：</label>
          <div class="layui-input-block">
               <input type="text" id="daxiao" name="daxiao"   placeholder="请输入大小"  class="layui-input" style="margin-right: 95px;width: 95%;">
          </div>
        </div>

        <!-- <div class="layui-form-item">
          <label class="layui-form-label">URL类型</label>
          <div class="layui-input-block">
            <select name="url_type" lay-verify="required">
              <option value="wxv">wxv</option>
              <option value="mu38">mu38</option>
              <option value="qita">其他</option>
            </select>
          </div>
        </div> -->



          <div class="layui-form-item">
            <div class="layui-input-block">
              <button class="layui-btn" type="submit" lay-submit lay-filter="formDemo">保存</button>
              <button type="reset" class="layui-btn layui-btn-primary">恢复 </button>
            </div>
          </div>
    </form>
</div>
<script src="../vendor/js/jquery.js"></script>
<script src="../vendor/layui/layui.js"></script>
<script src="../custom/js/admin.js"></script>
<script>
    //Demo
    layui.use(['form','upload','element'], function(){
      var form = layui.form;
      var layer=layui.layer;
      var upload = layui.upload;
      var uploadInst = upload.render({
      elem: '#test1' //绑定元素
      ,url: '../../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#logo").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
   var uploadInst = upload.render({
      elem: '#test2' //绑定元素
      ,url: '../../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#image1").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
      
   var uploadInst = upload.render({
      elem: '#test3' //绑定元素
      ,url: '../../upimg.php' //上传接口
      ,field:'file'
      ,done: function(res){
      //上传完毕回调
      console.log(res);
   if (res.code==200) {
        layer.msg('上传成功');
        $("input#image2").val(res['msg']);  
      }else{
       layer.msg(res['msg']); 
      }
      }
      ,error: function(){
      //请求异常回调
      }
      });
      
 //上传软件
              upload.render({
                    elem:'#url1',
                    url:'../../upload.php',
                    accept:'file',         
 
                    before: function (obj) { //obj参数包含的信息，跟 choose回调完全一致，可参见上文。
                            index = layer.load(1); //上传loading //上传logo
                    },
                    done:function (res) {
                  console.log(res)     
                   if(res.code==200){
                   layer.close(index)
                    $("#url").val(res.msg);
                    $("#daxiao").val(res.size);
                    layer.msg('上传成功', {icon: 1});   
                     }else{
                     layer.msg(res.msg, {icon: 5});     
                     }
                    },
                    error:function () {
                        console.log('上传失败', {icon: 5})
                    }
                })
      
      
  
    });
    </script>
</body>
</html>