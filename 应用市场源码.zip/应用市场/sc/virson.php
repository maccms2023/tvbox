<?php
include('../confng.php');
$uid=1;
$title="桌面后台管理";

$sql="SELECT * FROM virson ORDER BY id DESC limit 1";
$res12=$mysql->query($sql);
$row12=$res12->fetch_array(MYSQLI_ASSOC);


if($_GET['do']=='edat'){
$virsonhoa=$_POST['virsonhao'];
$desc=$_POST['quxanqa'];
$url=$_POST['url'];
$time=time();
// echo($time);
// die();
 $sql="INSERT INTO virson(virson,quxanqa,url,create_time)VALUES('{$virsonhoa}','{$desc}','{$url}','{$time}')";
if($mysql->query($sql)===TRUE){
    echo "<script>alert('添加成功  ,  页面更新一下');</script>";
}else{
    echo "<script>alert('添加失败');</script>";
    //  echo("添加失败".$mysql->connect_eror);
}
}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>网站配置</title>
    <link rel="stylesheet" href="vendor/layui/css/layui.css">
    <link rel="stylesheet" href="custom/css/style.css">
    <link rel="stylesheet" href="custom/css/font.css">
</head>
<body style="padding:0 10px;">
<div class="layui-col-xs10">
    <form class="layui-form" action="virson.php?do=edat" enctype="multipart/form-data" method="post">
          <div class="layui-form-item">
          <label class="layui-form-label">应用版本 ：</label>
          <div class="layui-input-block">
            <input type="text" name="virsonhao" value="<?php echo $row12['virson']?>" required  lay-verify="required" placeholder="请输入版本号 ！" autocomplete="off" class="layui-input">
          </div>
        </div>


          
        <div class="layui-form-item">
          <label class="layui-form-label">详情 ：</label>
          <div class="layui-input-block">
              <input style="height:150px" type="text" name="quxanqa" value="<?php echo $row12['quxanqa']?>" required  lay-verify="required" placeholder="请输入版本号 ！" autocomplete="off" class="layui-input">
          </div>
        </div>


        <div class="layui-form-item">
          <label class="layui-form-label">软件地址</label>
          <div class="layui-input-block">
            <input type="text" name="url" value="<?php echo $row12['url']?>" required  lay-verify="required" placeholder="请输入下载地址" autocomplete="off" class="layui-input">
          </div>
        </div>


          <div class="layui-form-item">
            <div class="layui-input-block">
              <button class="layui-btn" lay-submit lay-filter="formDemo">确定</button>
              <button type="reset" class="layui-btn layui-btn-primary">恢复原状</button>
            </div>
          </div>
    </form>
</div>
<script src="vendor/js/jquery.js"></script>
<script src="vendor/layui/layui.js"></script>
<script src="custom/js/admin.js"></script>
<script>
    //Demo
    layui.use(['form','upload','element'], function(){
      var form = layui.form;
      var layer=layui.layer;
      var upload = layui.upload;
      
    });
    </script>
</body>
</html>