<?php

$serevername="localhost";
$username="sicai";
$password="123456";
$dbname="sicai";

$mysql=new mysqli($serevername,$username,$password,$dbname);
if ($mysql->connect_eror) {
   die("数据库连接失败".$mysql->connect_eror);
}

if($_GET['do']=='qikin'){
    unset($_SESSION['id']);
   
}
if($_GET['do']=='login'){
$name=$_POST['name'];
$password=$_POST['password'];

$sql="SELECT * FROM admin where name='$name' and password='$password'";
$res=$mysql->query($sql);
$ra=$res->fetch_array(MYSQLI_ASSOC);
if(is_array($ra)==true){
//  当验证通过后，启动 Session
    session_start();
    //  注册登陆成功的 admin 变量，并赋值 true
    $_SESSION["admin"] = true;
    header("location:index.php");
}else{
    echo "<script>alert('账号，密码说了');</script>";
}
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>桌面后台管理</title>
    <link rel="stylesheet" href="vendor/layui/css/layui.css">
    <link rel="stylesheet" href="custom/css/login.css">
    <link rel="stylesheet" href="custom/css/font.css">
</head>
<body>
<div class="layui-anim layui-anim-up login-main" >
    <form class="layui-form"  action="login.php?do=login" enctype="multipart/form-data" method="post">
        <h3 style="color:#ee609c">桌面后台管理</h3>
        <div class="ly-input">
            <input type="text" name="name" placeholder="账号" autocomplete="off" class="layui-input">
        </div>
        <div class="ly-input">
            <input type="password" name="password" placeholder="密码" autocomplete="off" class="layui-input">
        </div>
       
        <div class="ly-input">
            <button class="layui-btn layui-btn-danger ly-submit" type="submit">登录</button>
        </div>
    </form>
    <p>更多免费资源请访问一生相随博客：<a target="_blank" href="https://www.520xv.com">https://www.520xv.com</a></p>
</div>

<script src="vendor/js/jquery.js"></script>
<script src="vendor/layui/layui.js"></script>
<script src="custom/js/login.js"></script>

</body>
</html>