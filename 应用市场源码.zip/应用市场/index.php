<?php
include('confng.php');

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>恭！</title>
    <style>
        .container {
            width: 60%;
            margin: 10% auto 0;
            background-color: #f0f0f0;
            padding: 2% 5%;
            border-radius: 10px
        }

        ul {
            padding-left: 20px;
        }

            ul li {
                line-height: 2.3
            }

        a {
            color: #20a53a
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>恭喜, 站点创建成功！</h1>
        <h3>这是默认index.html，本页面由系统自动生成</h3>
        <ul>
            <li>本页面在FTP根目录下的index.html</li>
            <li>您可以修改、删除或覆盖本页面</li>
            <li>FTP相关信息，请到“面板系统后台 > FTP” 查看</li>
            <li>更多功能了解，请查看<a href="https://www.bt.cn" target="_blank">宝塔官网(www.bt.cn)</a></li>
        </ul>
    </div>
</body>
</html>