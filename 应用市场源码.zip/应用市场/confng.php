<?php 
$serevername="localhost";//服务器地址：默认localhost
$username="sicai";//数据库名
$pass="123456";//数据库密码
$dbname="sicai";//数据表名

$mysql=new mysqli($serevername,$username,$pass,$dbname);

if($mysql->connect_eror) {
   echo("数据库连接失败".$mysql->connect_eror);
}
?>