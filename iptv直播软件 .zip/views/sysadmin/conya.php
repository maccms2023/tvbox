<?php

$sourceDir = __DIR__; // 

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (isset($_FILES["zip_file"])) {
        $zipFile = $_FILES["zip_file"]["tmp_name"];
        $zipName = $_FILES["zip_file"]["name"];

        $destinationDir = $sourceDir . '/'; 


        $zip = new ZipArchive();
        if ($zip->open($zipFile) === TRUE) {
            $zip->extractTo($destinationDir);  //
            $zip->close();
            echo "文件 '$zipName' 上传并解压成功！解压目录: " . $destinationDir;
        } else {
            echo "解压文件 '$zipName' 失败！请检查文件格式或权限。";
        }
    }
    // 解压已经存在的 ZIP 文件
    elseif (isset($_POST['existing_zip'])) {
        $zipName = $_POST['existing_zip'];  // 
        $zipFilePath = $sourceDir . '/' . $zipName; // 
        // 直接在当前目录下解压
        $destinationDir = $sourceDir . '/'; 

        // 使用 ZipArchive 解压文件
        $zip = new ZipArchive();
        if ($zip->open($zipFilePath) === TRUE) {
            $zip->extractTo($destinationDir);  // 
            echo "文件 '$zipName' 解压成功！解压目录: " . $destinationDir;
        } else {
            echo "解压文件 '$zipName' 失败！请检查文件格式或权限。";
        }
    }
}


$existingFiles = array_filter(scandir($sourceDir), function($file) use ($sourceDir) {
    return pathinfo($file, PATHINFO_EXTENSION) === 'zip' && is_file($sourceDir . '/' . $file);
});
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<body>


    <!-- 文件上传部分 -->
    <h2>上传 ZIP 文件并解压</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <label for="zip_file">选择 ZIP 文件：</label>
        <input type="file" name="zip_file" id="zip_file" accept=".zip" required>
        <button type="submit">上传并解压</button>
    </form>

    <!-- 已有 ZIP 文件解压部分 -->
    <h2>选择已有 ZIP 文件进行解压</h2>
    <form action="" method="post">
        <label for="existing_zip">选择已有 ZIP 文件：</label>
        <select name="existing_zip" id="existing_zip" required>
            <option value="">请选择一个文件</option>
            <?php
      
            foreach ($existingFiles as $file) {
                echo "<option value=\"$file\">$file</option>";
            }
            ?>
        </select>
        <button type="submit">解压选择的文件</button>
    </form>
</body>
</html>
