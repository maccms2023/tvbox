<?php
include_once "config.php";
$db = Config::GetIntance();

$id=$_GET['id'];
$db->mSet("apod_users", "vpn=vpn+1,status=0", "where name=$id");
?>