<?php
$url = "http://epg.51zmt.top:8000/e.xml";
$save_dir = "./cache/"; // 服务资源目录
$filename = "51zmt.xml"; // 自定义名称
$result = getFile($url, $save_dir, $filename,1);


function getFile($url, $save_dir = '', $filename = '', $type = 1)
{
	if (trim($url) == '') {
		return false;
	}
	if (trim($save_dir) == '') {
		$save_dir = './';
	}
	if (0 !== strrpos($save_dir, '/')) {
		$save_dir.= '/';
	}
	//创建保存目录
	if (!file_exists($save_dir) && !mkdir($save_dir, 0777, true)) {
		return false;
	}
	//获取远程文件所采用的方法
	if ($type) {
		$ch = curl_init();
		$timeout = 1000;
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		$content = curl_exec($ch);
		curl_close($ch);
	} else {
		ob_start();
		readfile($url);
		$content = ob_get_contents();
		ob_end_clean();
	}
	$size = strlen($content);
	//文件大小
	$fp2 = @fopen($save_dir . $filename, 'a');
	fwrite($fp2, $content);
	fclose($fp2);
	unset($content, $url);
	$res['code'] = 200;
	$res['fild_name'] = $filename;
	return $res;
}

?>