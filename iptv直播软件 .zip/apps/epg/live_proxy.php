<?php
$URI = empty($_GET['URI']) ? "" : trim($_GET['URI']);
@parse_str(base64_decode($URI));
// echo $HTTPHEADER;
// exit;
$ch = curl_init();
if($URL){
    curl_setopt($ch,CURLOPT_URL,base64_decode($URL));
}
if($FOLLOWLOCATION){
   curl_setopt($ch,CURLOPT_FOLLOWLOCATION,$FOLLOWLOCATION); 
}
if($RETURNTRANSFER){
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,$RETURNTRANSFER); 
}
if($HEADER){
    curl_setopt($ch, CURLOPT_HEADER, $HEADER);
}
if($NOBODY){
    curl_setopt($ch, CURLOPT_NOBODY, $NOBODY);
}
if($HTTP_VERSION){
    curl_setopt($ch, CURLOPT_HTTP_VERSION, $HTTP_VERSION);
}
if($NOSIGNAL){
    curl_setopt($ch, CURLOPT_NOSIGNAL, $NOSIGNAL);
}
if($TIMEOUT_MS){
    curl_setopt($ch, CURLOPT_TIMEOUT_MS, $TIMEOUT_MS);
}
if($CONNECTTIMEOUT_MS){
    curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT_MS, $CONNECTTIMEOUT_MS);
}
if($SSL){
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
}
if($HTTPHEADER){
    curl_setopt($ch, CURLOPT_HTTPHEADER,unserialize($HTTPHEADER));
}
if($POSTFIELDS){
    curl_setopt($ch, CURLOPT_POST,1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, base64_decode($POSTFIELDS));
}
if($PROXY){
    curl_setopt($ch, CURLOPT_PROXYAUTH, CURLAUTH_BASIC); 
    curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP); 
    curl_setopt($ch, CURLOPT_PROXY, $PROXY); 
}
if($RESOLVE){
    curl_setopt($ch, CURLOPT_RESOLVE, unserialize($RESOLVE));
}
if($CUSTOMREQUEST){
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $CUSTOMREQUEST);
}
if($MAXREDIRS){
    curl_setopt($ch, CURLOPT_MAXREDIRS, $MAXREDIRS);
}
    $result = curl_exec($ch);
if($info){
    $info = curl_getinfo($ch);
    echo serialize($info);
}
if($error){
    $error = curl_error($ch);
    echo $error;
}
if($return){
    echo $result;
}
curl_close($ch);
?>